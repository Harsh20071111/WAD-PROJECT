# Multi-Vendor Local Marketplace

Empty project scaffold matching the structure described in `Multi-Vendor-Marketplace-Report.docx`
(see the docs/ folder). Stack: React (JS) + Node/Express + MongoDB only, no TypeScript, no SQL.

## Getting started
1. `cd client && npm create vite@latest . -- --template react` (or drop your own React app in here)
2. `cd server && npm init -y && npm install express mongoose dotenv jsonwebtoken bcryptjs multer cloudinary cors`
3. Fill in server/.env using .env.example as a guide (MONGO_URI, JWT_SECRET, CLOUDINARY_* keys, RAZORPAY_* keys)
4. Start building models first (server/models/), they mirror the schema in the report.

## Structure
See section 7 of the report for the full annotated tree.
